package com.example.myapplication.View.Diagram;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.R;
import com.example.myapplication.View.History.HistoryActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

public class RSDiagramActivity extends AppCompatActivity {

    FirebaseDatabase db = FirebaseDatabase.getInstance();
    DatabaseReference myRef = db.getReference();
    LineChartView lineChartViewPM;
    LineChartView lineChartViewCO;
    LineChartView lineChartViewDust;
    LineChartView lineChartViewTemp;
    LineChartView lineChartViewHum;
    Button fullHistory;
    Toolbar toolbar;
    String[] axisData = {"6:00", "7:00","8:00","9:00","10:00"};
    double[] yAxisDataPM1 = {0,0,0,0,0};
    double[] yAxisDataPM25 = {0,0,0,0,0};
    double[] yAxisDataPM10 = {0,0,0,0,0};

    double[] yAxisDataCO = {0,0,0,0,0};

    double[] yAxisDataDust = {0,0,0,0,0};

    double[] yAxisDataTemp = {0,0,0,0,0};
    double[] yAxisDataHum = {0,0,0,0,0};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_r_s_diagram);

        toolbar = findViewById(R.id.toolbar_diagram);
        toolbar.setTitle("Lịch sử đo");
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_ios_24);

        lineChartViewPM = findViewById(R.id.chart_pm);
        lineChartViewCO = findViewById(R.id.chart_co);
        lineChartViewDust = findViewById(R.id.chart_gust);
        lineChartViewHum = findViewById(R.id.chart_hum);
        lineChartViewTemp = findViewById(R.id.chart_temp);
        fullHistory = findViewById(R.id.full);

        fullHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RSDiagramActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });

        drawDiagram();

        updateState();

    }

    private void updateState() {
        myRef.child("home1").child("time").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    String time = postSnapShot.getValue(String.class);
                    axisData[tmp] = time.substring(10);
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("dust").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double dust = postSnapShot.getValue(Double.class);
                    yAxisDataDust[tmp] = dust;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("co").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double co = postSnapShot.getValue(Double.class);
                    yAxisDataCO[tmp] = co;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("hum").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double hum = postSnapShot.getValue(Double.class);
                    yAxisDataHum[tmp] = hum;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("temp").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double temp = postSnapShot.getValue(Double.class);
                    yAxisDataTemp[tmp] = temp;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("pm1").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double co = postSnapShot.getValue(Double.class);
                    yAxisDataPM1[tmp] = co;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("pm25").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double co = postSnapShot.getValue(Double.class);
                    yAxisDataPM25[tmp] = co;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        myRef.child("home1").child("pm10").limitToLast(5).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                int tmp = 0;
                for (DataSnapshot postSnapShot : snapshot.getChildren()) {
                    Double co = postSnapShot.getValue(Double.class);
                    yAxisDataPM10[tmp] = co;
                    tmp++;
                    if(tmp == 5){
                        break;
                    }
                }
                drawDiagram();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void drawDiagram() {




        List yAxisValuesPM1 = new ArrayList();
        List axisValuesPM1 = new ArrayList();
        Line linePM1 = new Line(yAxisValuesPM1).setColor(Color.parseColor("#f5a742"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesPM1.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataPM1.length; i++) {
            yAxisValuesPM1.add(new PointValue(i, (float) yAxisDataPM1[i]));
        }


        List yAxisValuesPM2 = new ArrayList();
        List axisValuesPM2 = new ArrayList();
        Line linePM2 = new Line(yAxisValuesPM2).setColor(Color.parseColor("#4287f5"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesPM2.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataPM25.length; i++) {
            yAxisValuesPM2.add(new PointValue(i, (float) yAxisDataPM25[i]));
        }


        List yAxisValuesPM10 = new ArrayList();
        List axisValuesPM10 = new ArrayList();
        Line linePM10 = new Line(yAxisValuesPM10).setColor(Color.parseColor("#f54842"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesPM10.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataPM10.length; i++) {
            yAxisValuesPM10.add(new PointValue(i, (float) yAxisDataPM10[i]));
        }


        List lines = new ArrayList();
        lines.add(linePM1);
        lines.add(linePM2);
        lines.add(linePM10);

        LineChartData data = new LineChartData();
        data.setLines(lines);

        Axis axis = new Axis();
        axis.setValues(axisValuesPM10);
        axis.setTextColor(Color.parseColor("#03A9F4"));
        axis.setTextSize(8);
        data.setAxisXBottom(axis);

        Axis yAxis = new Axis();
        yAxis.setName("ug/m^3");
        yAxis.setTextColor(Color.parseColor("#03A9F4"));
        yAxis.setTextSize(10);
        data.setAxisYLeft(yAxis);

        lineChartViewPM.setLineChartData(data);

        List yAxisValuesCO = new ArrayList();
        List axisValuesCO = new ArrayList();
        Line lineCO = new Line(yAxisValuesCO).setColor(Color.parseColor("#f54842"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesCO.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataPM10.length; i++) {
            yAxisValuesCO.add(new PointValue(i, (float) yAxisDataCO[i]));
        }


        List linesCO = new ArrayList();
        linesCO.add(lineCO);

        LineChartData dataCO = new LineChartData();
        dataCO.setLines(linesCO);

        Axis axisC0 = new Axis();
        axisC0.setValues(axisValuesPM10);
        axisC0.setTextColor(Color.parseColor("#03A9F4"));
        axisC0.setTextSize(8);
        dataCO.setAxisXBottom(axisC0);

        Axis yAxisC0 = new Axis();
        yAxisC0.setTextColor(Color.parseColor("#03A9F4"));
        yAxisC0.setTextSize(8);
        dataCO.setAxisYLeft(yAxisC0);

        lineChartViewCO.setLineChartData(dataCO);

        List yAxisValuesDust = new ArrayList();
        List axisValuesDust = new ArrayList();
        Line lineGust = new Line(yAxisValuesDust).setColor(Color.parseColor("#f54842"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesDust.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataDust.length; i++) {
            yAxisValuesDust.add(new PointValue(i, (float) yAxisDataDust[i]));
        }


        List linesDust = new ArrayList();
        linesDust.add(lineGust);

        LineChartData dataDust = new LineChartData();
        dataDust.setLines(linesDust);

        Axis axisGust = new Axis();
        axisGust.setValues(axisValuesDust);
        axisGust.setTextColor(Color.parseColor("#03A9F4"));
        axisGust.setTextSize(8);
        dataDust.setAxisXBottom(axisGust);

        Axis yAxisDust = new Axis();
        yAxisDust.setTextColor(Color.parseColor("#03A9F4"));
        yAxisDust.setTextSize(10);
        dataDust.setAxisYLeft(yAxisDust);

        lineChartViewDust.setLineChartData(dataDust);



        // Biểu đồ nhiệt độ
        List yAxisValuesTemp = new ArrayList();
        List axisValuesTemp = new ArrayList();
        Line lineTemp = new Line(yAxisValuesTemp).setColor(Color.parseColor("#f54842"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesTemp.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataTemp.length; i++) {
            yAxisValuesTemp.add(new PointValue(i, (float) yAxisDataTemp[i]));
        }

        List linesTemp = new ArrayList();
        linesTemp.add(lineTemp);

        LineChartData dataTemp = new LineChartData();
        dataTemp.setLines(linesTemp);

        Axis axisTemp = new Axis();
        axisTemp.setValues(axisValuesTemp);
        axisTemp.setTextColor(Color.parseColor("#03A9F4"));
        axisTemp.setTextSize(8);
        dataTemp.setAxisXBottom(axisTemp);

        Axis yAxisTemp = new Axis();
        yAxisTemp.setTextColor(Color.parseColor("#03A9F4"));
        yAxisTemp.setTextSize(10);
        dataTemp.setAxisYLeft(yAxisTemp);

        lineChartViewTemp.setLineChartData(dataTemp);

        // Biểu đồ độ ẩm
        List yAxisValuesHum = new ArrayList();
        List axisValuesHum = new ArrayList();
        Line lineHum = new Line(yAxisValuesHum).setColor(Color.parseColor("#f54842"));

        for (int i = 0; i < axisData.length; i++) {
            axisValuesHum.add(i, new AxisValue(i).setLabel(axisData[i]));
        }

        for (int i = 0; i < yAxisDataHum.length; i++) {
            yAxisValuesHum.add(new PointValue(i, (float) yAxisDataHum[i]));
        }

        List linesHum = new ArrayList();
        linesHum.add(lineHum);

        LineChartData dataHum = new LineChartData();
        dataHum.setLines(linesHum);

        Axis axisHum = new Axis();
        axisHum.setValues(axisValuesHum);
        axisHum.setTextColor(Color.parseColor("#03A9F4"));
        axisHum.setTextSize(8);
        dataHum.setAxisXBottom(axisHum);

        Axis yAxisHum = new Axis();
        yAxisHum.setTextColor(Color.parseColor("#03A9F4"));
        yAxisHum.setTextSize(10);
        dataHum.setAxisYLeft(yAxisHum);

        lineChartViewHum.setLineChartData(dataHum);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
}