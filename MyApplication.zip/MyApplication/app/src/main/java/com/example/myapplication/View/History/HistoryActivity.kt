package com.example.myapplication.View.History

import android.app.ActionBar
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.MeasureSpec
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.Model.Adapter
import com.example.myapplication.Model.Detail
import com.example.myapplication.R
import com.google.firebase.database.*
import java.util.*


class HistoryActivity : AppCompatActivity() {

    val db: FirebaseDatabase = FirebaseDatabase.getInstance()
    val myRef: DatabaseReference = db.getReference()

    var layoutManager: RecyclerView.LayoutManager? = null
    var adapter: Adapter? = null
    var arrayList = ArrayList<Detail>()
    var recyclerView: RecyclerView? = null
    var length: Int = 0
        set(value: Int) {
            updateInfo()
        }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        var toolbar = findViewById<Toolbar>(R.id.toolbar_diagram)
        toolbar.setTitle("Lịch sử đầy đủ")
        setSupportActionBar(toolbar)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_ios_24)

        recyclerView = findViewById(R.id.rv)
        getRecyclerView()
        updateState()
    }

    private fun updateInfo() {
        Log.d("testPM", "aqqqq")
        myRef.child("home1").child("temp").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].temp = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("hum").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].hum = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("dust").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].dust = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("time").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(String::class.java)
                    arrayList[tmp].time = value!!
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("co").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].co = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("pm1").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].pm1 = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("pm25").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].pm25 = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })

        myRef.child("home1").child("pm10").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                var tmp = 0
                for (child in snapshot.children) {
                    val value = child.getValue(Double::class.java).toString()
                    arrayList[tmp].pm10 = value
                    tmp = tmp + 1
                    if (tmp == length)
                        break
                }
                adapter!!.notifyDataSetChanged()
            }

        })
    }

    private fun updateState() {
        Log.d("testPM", "a")
        myRef.child("home1").child("count_time").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onCancelled(error: DatabaseError) {

            }

            override fun onDataChange(snapshot: DataSnapshot) {
                arrayList.clear()
                val value = snapshot.getValue(Int::class.java)
                if (value != null) {
                    for (i in 0..(value-1)) {
                        arrayList.add(Detail("0", "0", "0", "0", "0", "0","0","0"))
                    }
                    adapter!!.notifyDataSetChanged()
                    length = value
                }
            }

        })
    }

    fun getRecyclerView() {
        layoutManager = LinearLayoutManager(applicationContext)
        adapter = Adapter(applicationContext, arrayList)
        recyclerView!!.adapter = adapter
        recyclerView!!.layoutManager = layoutManager
        recyclerView!!.setHasFixedSize(true)
        recyclerView!!.isNestedScrollingEnabled = true
        recyclerView!!.isFocusable = false
    }
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menuhistory, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
        }
        if (item.itemId == R.id.reload) {
            updateState()
        }
        return super.onOptionsItemSelected(item)
    }
}