package com.example.myapplication.Model

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R

class Adapter(var context: Context?, var arrayList: ArrayList<Detail>) :
        RecyclerView.Adapter<Adapter.itemAdapterVH>() {
    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): itemAdapterVH {
        return itemAdapterVH(LayoutInflater.from(context).inflate(R.layout.custom_list,p0,false))
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    override fun onBindViewHolder(p0: itemAdapterVH, p1: Int) {
        val detail = arrayList[p1]
        p0.txtTime.text = detail.time
        p0.txtCO.text = detail.co
        p0.txt1.text = detail.pm1
        p0.txt25.text = detail.pm25
        p0.txt10.text = detail.pm10
        p0.txtDust.text = detail.dust
        p0.txtTemp.text = detail.temp
        p0.txtHum.text = detail.hum
    }

    class itemAdapterVH(itemView: View) : RecyclerView.ViewHolder(itemView){
        val txtTime = itemView.findViewById<View>(R.id.item_time) as TextView
        val txtCO = itemView.findViewById<View>(R.id.item_co) as TextView
        val txt1 = itemView.findViewById<View>(R.id.item_1) as TextView
        val txt25 = itemView.findViewById<View>(R.id.item_25) as TextView
        val txt10 = itemView.findViewById<View>(R.id.item_10) as TextView
        val txtDust = itemView.findViewById<View>(R.id.item_dust) as TextView
        val txtTemp = itemView.findViewById<View>(R.id.item_tem) as TextView
        val txtHum = itemView.findViewById<View>(R.id.item_hum) as TextView
    }
}
