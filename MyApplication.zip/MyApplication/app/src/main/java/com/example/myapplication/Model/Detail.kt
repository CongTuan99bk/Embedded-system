package com.example.myapplication.Model

class Detail(
        var time: String = "",
        var co: String = "",
        var pm1: String = "",
        var pm25: String = "",
        var pm10: String = "",
        var dust: String = "",
        var temp: String = "",
        var hum: String = ""
) {}