package com.example.myapplication.Model

class HUser(
    var mAccount: User = User(),
    var mPermission: Int = 0
){}