package com.example.myapplication.View.Home

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.DialogInterface
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.myapplication.R
import com.example.myapplication.View.Authentication.MainActivity
import com.example.myapplication.View.Authentication.RegisterActivity
import com.example.myapplication.View.Diagram.RSDiagramActivity
import com.google.firebase.database.*


class HomeActivity : AppCompatActivity() {

    val db : FirebaseDatabase = FirebaseDatabase.getInstance()
    val myRef : DatabaseReference = db.getReference()
    var txtGust: TextView? = null
    var txtCO: TextView? = null
    var txtPM1: TextView? = null
    var txtPM25: TextView? = null
    var txtPM10: TextView? = null
    var txtTemp: TextView? = null
    var txtHum: TextView? = null
    var txtTime: TextView? = null
    var txtWellcome: TextView? = null
    var curPermission : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        txtGust = findViewById(R.id.txt_gust)
        txtCO = findViewById(R.id.txt_co)
        txtPM1 = findViewById(R.id.txt_pm1)
        txtPM25 = findViewById(R.id.txt_pm25)
        txtPM10 = findViewById(R.id.txt_pm10)
        txtTime = findViewById(R.id.txt_time)
        txtWellcome = findViewById(R.id.txt_wellcome)
        txtTemp = findViewById(R.id.txt_temp)
        txtHum = findViewById(R.id.txt_hum)

        curPermission = this.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE).getInt("currentpermission",-1)

        txtWellcome!!.text = "Xin chào, " + this.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE).getString("currentname","")

        val toolbar: Toolbar = findViewById(R.id.toolBar) as Toolbar
        toolbar.setTitle("")
        setSupportActionBar(toolbar)
        toolbar.setTitle("")

        updateState()

    }

    private fun updateState() {
        val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
        myRef.child("home1").child("time").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtTime!!.text = dataSnapshot.children.last().getValue(String::class.java)
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("temp").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtTemp!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " °C"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("temp",0f)) {
                    createNotiTemp()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("hum").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtHum!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " %"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("hum",0f)) {
                    createNotiHum()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("co").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtCO!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " ppm"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("co",0f)) {
                    createNotiCO()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("dust").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtGust!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString()
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("gust",0f)) {
                    createNotiDust()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm1").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtPM1!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " ug/m^3"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("pm1",0f)) {
                    createNotiPM1()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm25").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtPM25!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " ug/m^3"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("pm25",0f)) {
                    createNotiPM25()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm10").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                txtPM10!!.text = dataSnapshot.children.last().getValue(Double::class.java).toString() + " ug/m^3"
                if (dataSnapshot.children.last().getValue(Double::class.java)!!.toFloat() >= sharedPreferences.getFloat("pm10",0f)) {
                    createNotiPM10()
                }
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("co_ng").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                edit.putFloat("co", dataSnapshot.getValue(Float::class.java)!!)
                edit.commit()
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("dust_ng").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                edit.putFloat("dust", dataSnapshot.getValue(Float::class.java)!!)
                edit.commit()
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm1_ng").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                edit.putFloat("pm1", dataSnapshot.getValue(Float::class.java)!!)
                edit.commit()
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm25_ng").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                edit.putFloat("pm25", dataSnapshot.getValue(Float::class.java)!!)
                edit.commit()
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })

        myRef.child("home1").child("pm10_ng").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                edit.putFloat("pm10", dataSnapshot.getValue(Float::class.java)!!)
                edit.commit()
            }
            override fun onCancelled(@NonNull databaseError: DatabaseError) {

            }
        })
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menuhome, menu)
        return true
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.setting) {
            val builder1 = AlertDialog.Builder(this)
            val view1 = LayoutInflater.from(this).inflate(R.layout.custom_dialog_maxhum_maxtem,null,false)
            val txtNg : TextView = view1.findViewById(R.id.dialog_txt_curNg1)
            val txtNg2 : TextView = view1.findViewById(R.id.dialog_txt_curNg2)
            val edtCO : EditText = view1.findViewById(R.id.dialog_edt_co)
            val edtPM1 : EditText = view1.findViewById(R.id.dialog_edt_pm1)
            val edtPM25 : EditText = view1.findViewById(R.id.dialog_edt_pm25)
            val edtPM10 : EditText = view1.findViewById(R.id.dialog_edt_pm10)
            val edtDust : EditText = view1.findViewById(R.id.dialog_edt_dust)
            val edtTemp : EditText = view1.findViewById(R.id.dialog_edt_temp)
            val edtHum : EditText = view1.findViewById(R.id.dialog_edt_hum)
            val btnConfirm : Button = view1.findViewById(R.id.dialog_btn_confirm_hum_tem)

            val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
            txtNg.text = ""
            txtNg2.text = ""
            edtCO.setText(sharedPreferences.getFloat("co",0f).toString())
            edtPM1.setText(sharedPreferences.getFloat("pm1",0f).toString())
            edtPM25.setText(sharedPreferences.getFloat("pm25",0f).toString())
            edtPM10.setText(sharedPreferences.getFloat("pm10",0f).toString())
            edtDust.setText(sharedPreferences.getFloat("dust",0f).toString())
            edtTemp.setText(sharedPreferences.getFloat("temp",0f).toString())
            edtHum.setText(sharedPreferences.getFloat("hum",0f).toString())

            builder1.setView(view1)
            val alertDialog1 = builder1.create()
            alertDialog1.show()

            btnConfirm.setOnClickListener {
                val sharedPreferences = getSharedPreferences("home", MODE_PRIVATE)
                val edit = sharedPreferences.edit()
                if (edtCO.text.toString().length != 0) {
                    edit.putFloat("co", edtCO.text.toString().toFloat())
                    myRef.child("home1").child("co_ng").setValue(edtCO.text.toString().toFloat())
                }

                if (edtPM1.text.toString().length != 0) {
                    edit.putFloat("pm1", edtPM1.text.toString().toFloat())
                    myRef.child("home1").child("pm1_ng").setValue(edtPM1.text.toString().toFloat())
                }

                if (edtPM25.text.toString().length != 0) {
                    edit.putFloat("pm25", edtPM25.text.toString().toFloat())
                    myRef.child("home1").child("pm25_ng").setValue(edtPM25.text.toString().toFloat())
                }

                if (edtPM10.text.toString().length != 0) {
                    edit.putFloat("pm10", edtPM10.text.toString().toFloat())
                    myRef.child("home1").child("pm10_ng").setValue(edtPM10.text.toString().toFloat())
                }

                if (edtDust.text.toString().length != 0) {
                    edit.putFloat("dust", edtDust.text.toString().toFloat())
                    myRef.child("home1").child("dust_ng").setValue(edtDust.text.toString().toFloat())
                }

                if (edtTemp.text.toString().length != 0) {
                    edit.putFloat("temp", edtTemp.text.toString().toFloat())
                    myRef.child("home1").child("temp_ng").setValue(edtTemp.text.toString().toFloat())
                }

                if (edtHum.text.toString().length != 0) {
                    edit.putFloat("hum", edtHum.text.toString().toFloat())
                    myRef.child("home1").child("hum_ng").setValue(edtHum.text.toString().toFloat())
                }

                edit.commit()
                alertDialog1.dismiss()
            }
        } else if (item.itemId == R.id.history) {
            val intent: Intent = Intent(applicationContext,RSDiagramActivity::class.java)
            startActivity(intent)
        } else if (item.itemId == R.id.register){
            if(curPermission == 0){
                val intent1 = Intent(applicationContext, RegisterActivity::class.java)
                startActivity(intent1)
            }else if (curPermission == -1){
                Toast.makeText(applicationContext,"Chưa có quyền hiện hành", Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(applicationContext,"Chỉ có chủ nhà mới sử dụng được tính năng này", Toast.LENGTH_SHORT).show()
            }
        } else if (item.itemId == R.id.logout) {
            var alertDialog : androidx.appcompat.app.AlertDialog? = null
            val builderDelete = androidx.appcompat.app.AlertDialog.Builder(this)
            builderDelete.setTitle("Đăng xuất")
            builderDelete.setMessage("Bạn muốn đăng xuất khỏi ứng dụng?")
            builderDelete.setPositiveButton("Xác nhận", object : DialogInterface.OnClickListener{
                override fun onClick(dialog: DialogInterface?, which: Int) {
                    val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
                    val edit = sharedPreferences.edit()
                    edit.putString("currentuser", "")
                    edit.commit()

                    val intent = Intent(applicationContext,MainActivity::class.java)
                    startActivity(intent)
                }
            })
            builderDelete.setNegativeButton("Hủy", object : DialogInterface.OnClickListener{
                override fun onClick(dialog: DialogInterface?, which: Int) {
                    alertDialog!!.dismiss()
                }
            })
            alertDialog = builderDelete.create()
            alertDialog.show()
        }
        return super.onOptionsItemSelected(item)
    }

    fun createNotiChannel(id: String){
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            val name : String = "NotiChannel"
            val desc : String = "MyChannel"
            val important = NotificationManager.IMPORTANCE_DEFAULT
            val channel : NotificationChannel = NotificationChannel("MYAPP_"+id,name,important)
            channel.description = desc
            val notificationManager : NotificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }

    @SuppressLint("WrongConstant")
    fun createNotiCO() {
        createNotiChannel("01")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
                NotificationCompat.Builder(this, "MYAPP_01")
                        .setSmallIcon(R.drawable.ic_error_white_24dp)
                        .setContentTitle("Chỉ số CO xấu")
                        .setContentText("CO: "+txtCO!!.text.toString())
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(12, builder.build())
        }
    }

    fun createNotiPM1() {
        createNotiChannel("02")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
                NotificationCompat.Builder(this, "MYAPP_01")
                        .setSmallIcon(R.drawable.ic_error_white_24dp)
                        .setContentTitle("Chỉ số PM1 xấu")
                        .setContentText("PM1: "+txtPM1!!.text.toString())
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(11, builder.build())
        }
    }

    fun createNotiPM25() {
        createNotiChannel("05")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
                NotificationCompat.Builder(this, "MYAPP_01")
                        .setSmallIcon(R.drawable.ic_error_white_24dp)
                        .setContentTitle("Chỉ số PM25 xấu")
                        .setContentText("PM2.5: "+txtPM25!!.text.toString())
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(21, builder.build())
        }
    }

    fun createNotiPM10() {
        createNotiChannel("08")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
                NotificationCompat.Builder(this, "MYAPP_01")
                        .setSmallIcon(R.drawable.ic_error_white_24dp)
                        .setContentTitle("Chỉ số PM10 xấu")
                        .setContentText("PM10: "+txtPM10!!.text.toString() )
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(22, builder.build())
        }
    }

    fun createNotiDust() {
        createNotiChannel("03")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
                NotificationCompat.Builder(this, "MYAPP_01")
                        .setSmallIcon(R.drawable.ic_error_white_24dp)
                        .setContentTitle("Chỉ số Dust xấu")
                        .setContentText("Dust: "+txtGust!!.text.toString())
                        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                        .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(10, builder.build())
        }
    }

    fun createNotiTemp() {
        createNotiChannel("101")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
            NotificationCompat.Builder(this, "MYAPP_01")
                .setSmallIcon(R.drawable.ic_error_white_24dp)
                .setContentTitle("Chỉ số nhiệt độ xấu")
                .setContentText("Nhiệt độ: "+txtTemp!!.text.toString())
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(101, builder.build())
        }
    }

    fun createNotiHum() {
        createNotiChannel("102")

        val intent1 = Intent(this, HomeActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val penddingintent: PendingIntent = PendingIntent.getActivity(this, 0, intent1, 0)

        val builder =
            NotificationCompat.Builder(this, "MYAPP_01")
                .setSmallIcon(R.drawable.ic_error_white_24dp)
                .setContentTitle("Chỉ số độ ẩm xấu")
                .setContentText("Độ ẩm: "+txtHum!!.text.toString())
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                .setContentIntent(penddingintent).setAutoCancel(true)
        with(NotificationManagerCompat.from(this)) {
            notify(102, builder.build())
        }
    }

    override fun onBackPressed() {

    }
}