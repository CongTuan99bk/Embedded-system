package com.example.myapplication.View.Authentication

import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.example.myapplication.Model.HUser
import com.example.myapplication.Model.User
import com.example.myapplication.R
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.database.*

class RegisterActivity : AppCompatActivity() {

    val db : FirebaseDatabase = FirebaseDatabase.getInstance()
    val myRef : DatabaseReference = db.getReference()
    var btnRegister: Button? = null
    var txtName: TextInputEditText? = null
    var txtId: TextInputEditText? = null
    var txtPassword: TextInputEditText? = null
    var txtAddress: TextInputEditText? = null
    var txtConfirmPassword: TextInputEditText? = null
    var nameHome: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        var toolbar = findViewById<Toolbar>(R.id.toolBar_register)
        toolbar.setTitle("Đăng kí")
        setSupportActionBar(toolbar)

        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_ios_24)

        nameHome =
            getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE).getString("currenthome","")
                .toString()

        btnRegister = findViewById(R.id.btn_dangki)
        txtName = findViewById(R.id.edtinput_name)
        txtId = findViewById(R.id.edtinput_id)
        txtAddress = findViewById(R.id.edtinput_address)
        txtPassword = findViewById(R.id.edtinput_pass)
        txtConfirmPassword = findViewById(R.id.edtinput_confirmpass)

        btnRegister!!.setOnClickListener {
            register()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun register() {
        val email = txtId!!.text.toString()
        val password = txtPassword!!.text.toString()
        val conPassword = txtConfirmPassword!!.text.toString()
        val fullName = txtName!!.text.toString()
        val address = txtAddress!!.text.toString()
        val user = User(email, password, fullName,0,address,1,nameHome)
        val newUser = HUser(user,1)
        if (email.length != 0 && password.length != 0 && address.length != 0 && fullName.length != 0 && conPassword.length != 0) {
            if (!password.equals(conPassword)) {
                Toast.makeText(applicationContext, "Mật khẩu không khớp", Toast.LENGTH_SHORT).show()
            } else {
                myRef.child("Users").addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                        var tmp: Int =  0
                        for (snapshot in dataSnapshot.children) {
                            val user = snapshot.getValue(HUser::class.java)
                            if (user!!.mAccount.mId.equals(newUser)) {
                                tmp == 1
                                break
                            }
                        }
                        if(tmp == 0){
                            myRef.child("Users").child(newUser.mAccount.mId).setValue(newUser)
                            Toast.makeText(applicationContext, "Đăng kí thành công", Toast.LENGTH_SHORT).show()
                            finish()
                        }else{
                            Toast.makeText(applicationContext, "Tên đăng nhập đã có người dùng", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onCancelled(@NonNull databaseError: DatabaseError) {

                    }
                })
            }
        } else {
            Toast.makeText(applicationContext, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show()
        }

    }
}