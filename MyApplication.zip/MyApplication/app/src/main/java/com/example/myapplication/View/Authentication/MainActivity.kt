package com.example.myapplication.View.Authentication

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.Model.HUser
import com.example.myapplication.R
import com.example.myapplication.View.Home.HomeActivity
import com.google.firebase.database.*


@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {

    var edtEmail: EditText? = null
    var edtPass: EditText? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sharedPreferences = applicationContext.getSharedPreferences("home", AppCompatActivity.MODE_PRIVATE)
        if (sharedPreferences.getString("currentuser","")!!.length != 0 ) {
            val intent = Intent(applicationContext, HomeActivity::class.java)
            startActivity(intent)
        }

        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val btnLogin = findViewById<Button>(R.id.btn_login)
        edtEmail = findViewById(R.id.edt_email)
        edtPass = findViewById(R.id.edt_pass)

        btnLogin.setOnClickListener {
            dangnhap()
        }
    }

    private fun dangnhap() {
        val db : FirebaseDatabase = FirebaseDatabase.getInstance()
        val myRef : DatabaseReference = db.getReference()
        val email = edtEmail!!.getText().toString()
        val password = edtPass!!.getText().toString()
        if(email.length!=0 && password.length!=0){
            myRef.child("Users").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(@NonNull dataSnapshot: DataSnapshot) {
                    var tmp: Int = 0
                    for (snapshot in dataSnapshot.children) {
                        val user = snapshot.getValue(HUser::class.java)
                        if (email == user!!.mAccount.mId && password == user.mAccount.mPass) {
                            tmp++

                            val sharedPreferences = getSharedPreferences("home", MODE_PRIVATE)
                            val edit = sharedPreferences.edit()
                            edit.putString("currenthome", user.mAccount.mHome)
                            edit.putString("currentuser", user.mAccount.mId)
                            edit.putString("currentname", user.mAccount.mName)
                            edit.putInt("currentpermission", user.mAccount.mClassify)//0-admin
                            edit.apply()

                            val intent = Intent(applicationContext, HomeActivity::class.java)
                            intent.putExtra("id", user.mAccount.mId)
                            intent.putExtra("nameHome", user.mAccount.mHome)
                            startActivity(intent)
                        }
                    }
                    if(tmp==0){
                        Toast.makeText(applicationContext, "Đăng nhập thất bại", Toast.LENGTH_SHORT).show()
                    }else{
                        Toast.makeText(applicationContext, "Đăng nhập thành công", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(@NonNull databaseError: DatabaseError) {

                }
            })
        }else{
            Toast.makeText(applicationContext, "Vui lòng nhập đủ thông tin", Toast.LENGTH_SHORT).show()
        }

    }
}